<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: ../index.html");
    exit();
}
if (isset($_SESSION['expire_time']) && time() > $_SESSION['expire_time']) {
    $_SESSION = array();
    session_destroy();
    header("Location: ../index.html");
    exit();
}
$_SESSION['expire_time'] = time() + 3600;
?>
