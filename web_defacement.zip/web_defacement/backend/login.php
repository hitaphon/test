<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "informationDB";
$userInputUsername = $_POST['username'];
$userInputPassword = $_POST['password'];
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    $response = array('status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error);
    echo json_encode($response);
    die();
}
$sql = "SELECT * FROM users WHERE username=? AND password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userInputUsername, $userInputPassword);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $response = array('status' => 'success', 'message' => 'Login successful', 'redirectUrl' => 'script/dashboard.php');
    echo json_encode($response);
    $_SESSION["username"] = $userInputUsername;
} else {
    $response = array('status' => 'error', 'message' => 'Invalid username or password');
    echo json_encode($response);
}
$stmt->close();
$conn->close();
?>
