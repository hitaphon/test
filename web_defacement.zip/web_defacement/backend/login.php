<?php
session_start();

$servername = "192.168.20.142";
$username = "mysql5";
$password = "n";
$dbname = "informationDB";
$userInputUsername = $_POST['username'];
$userInputPassword = $_POST['password'];
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    $response = array('status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error);
    echo json_encode($response); // แก้ไขเพื่อให้ส่งคืน JSON
    die();
}
$sql = "SELECT * FROM users WHERE username=? AND password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $userInputUsername, $userInputPassword);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $response = array('status' => 'success', 'message' => 'Login successful', 'redirectUrl' => '../script/dashboard.php');
    echo json_encode($response); // แก้ไขเพื่อให้ส่งคืน JSON
    $_SESSION["username"] = $userInputUsername;
} else {
    $response = array('status' => 'error', 'message' => 'Invalid username or password');
    echo json_encode($response); // แก้ไขเพื่อให้ส่งคืน JSON
}
$stmt->close();
$conn->close();
?>

