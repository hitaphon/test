<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "informationDB";
$timezone = date_default_timezone_set("Asia/Bangkok");
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>